exports.handler = async (event) => {
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "IL6-Compliant AWS Environment Running Securely!" }),
    };
  };
  